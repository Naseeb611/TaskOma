//
//  LoginViewController.swift
//  TaskOma
//
//  Created by Naseeb on 22/11/21.
//

import UIKit

class LoginViewController: UIViewController {

    @IBOutlet weak var txtUsername: UITextField!
    @IBOutlet weak var txtPass: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    @IBAction func btnLogin(_ sender: Any) {
        if txtUsername.text == "naseeb" && txtPass.text == "12345" {
            let vc = UIStoryboard.instatiateListViewController()
             self.navigationController?.pushViewController(vc, animated: true)
        }else {
            showAlertViewWith(message: "Please enter the correct username annd password", ok: "OK")
        }
    }
}
